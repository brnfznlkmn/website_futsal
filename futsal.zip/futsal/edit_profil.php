<?php
session_start();
error_reporting(0);
//echo"lnlj";
include_once("config/koneksi.php");
$nama = mysqli_escape_string($koneksi,$_POST['namalengkap']);
$password = ($_POST['password']);
$passwordrep = ($_POST['passwordrep']);
$email = mysqli_escape_string($koneksi,$_POST['email']);
$jk = mysqli_escape_string($koneksi,$_POST['jeniskelamin']);
$hp = mysqli_escape_string($koneksi,$_POST['handphone']);
if(empty($_POST['namalengkap']) 
or empty($_POST['password']) 
or empty($_POST['email']) 
 
or empty($_POST['jeniskelamin']) 
or empty($_POST['handphone']) 
){
 echo"<script>alert('Silahkan Lengkapi Data Anda Terlebih Dahulu !');window.location.href='./'</script>";
}else{
	$sql = mysqli_query($koneksi,"update user set nama_lengkap='$nama',email='$email',password='$password',hp='$hp',jenis_kelamin='$jk',alamat='$_POST[alamat]' where id_user='$_SESSION[iduser]'");	
	if($sql){
		echo("<script>
			alert('Data Berhasil diubah');
			window.location='index.php';		
		</script>");
	}else{
		echo("<script>
			alert('Gagal ".mysqli_error($koneksi,)."');
			window.location='index.php';
		</script>");
	}
}
?>