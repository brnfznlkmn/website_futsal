<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
include_once("config/koneksi.php");

$email = mysqli_escape_string($koneksi, $_POST['email']);
$password = ($_POST['password']);

$qry = mysqli_query($koneksi, "SELECT * FROM user WHERE email='$email' AND password='$password'");
$numlogin = mysqli_num_rows($qry);

if($numlogin == 1){
    $ruser = mysqli_fetch_array($qry);
    $_SESSION['iduser'] = $ruser['id_user'];
    $_SESSION['nama'] = $ruser['nama_lengkap'];
    echo "<script>alert('Selamat Datang, $ruser[nama_lengkap]');window.location.href='index.php'</script>";
} else {
    $sql = mysqli_query($koneksi, "SELECT * FROM admin WHERE username='$email' AND password='$password'");
    if (!$sql) {
        echo "Error: " . mysqli_error($koneksi);
    }
    $data = mysqli_fetch_array($sql);

    if(mysqli_num_rows($sql) > 0){
        $_SESSION['id_user'] = $data['id_user'];
        $_SESSION['username'] = $data['username'];
        $_SESSION['password'] = $data['password'];
        echo "<script language=javascript>window.location='adm/home.php';</script>";
        exit;
    } else {
        echo "<script>alert('Login Gagal');window.location='index.php';</script>";
    }
}
?>