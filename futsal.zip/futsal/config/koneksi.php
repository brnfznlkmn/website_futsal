<?php
$host = 'localhost'; // Host MySQL
$user = 'mobw7774_brian'; // Pengguna MySQL
$password = 'brian7098'; // Kata sandi MySQL
$database = 'mobw7774_db_futsal'; // Nama database

// Buat koneksi
$koneksi = new mysqli($host, $user, $password, $database);

// Periksa koneksi
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}
?>
