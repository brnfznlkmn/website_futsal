<?php
session_start();
include_once("config/koneksi.php");

if(!isset($_SESSION['iduser'])){
    echo "<script>alert('Anda harus login terlebih dahulu');window.location.href='login.php'</script>";
    exit();
}

$iduser = $_SESSION['iduser'];

$sql = "SELECT * FROM sewa WHERE iduser = '$iduser'";
$result = $koneksi->query($sql);

if ($result === false) {
    die("Error: " . $koneksi->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Sewa</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2 class="mt-4">Data Sewa untuk User ID: <?php echo htmlspecialchars($iduser); ?></h2>
    <table class="table table-bordered mt-4">
        <thead>
            <tr>
                <th>idsewa</th>
                <th>iduser</th>
                <th>idlap</th>
                <th>tgl_pesan</th>
                <th>lama</th>
                <th>jmulai</th>
                <th>jhabis</th>
                <th>jns</th>
                <th>harga</th>
                <th>tot</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['idsewa']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['iduser']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['idlap']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['tgl_pesan']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['lama']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['jmulai']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['jhabis']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['jns']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['harga']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['tot']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='10'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
    <a href="index.php" class="btn btn-primary mt-3">Kembali</a>
</div>
</body>
</html>

<?php
$koneksi->close();
?>
