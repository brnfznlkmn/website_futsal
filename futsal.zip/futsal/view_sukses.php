<?php
	echo "<div class='alert alert-success'>Pendaftaran Sukses</div>
	      <p style='margin-top:60px'><center>Data yang anda inputkan sudah kami terima, dan akan di proses secepatnya,.. <br>silahkan menunggu info selanjutnya dari kami melalui sms atau email.<br>
	      							 Terima kasih,... ^_^</center></p>";
